# Real-Time Market Narrative Engine

An AI system for clustering and testing financial narratives.